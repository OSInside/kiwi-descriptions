#!/bin/bash

# called by dracut
check() {
    return 255
}

# called by dracut
depends() {
    echo network nfs
    return 0
}

# called by dracut
install() {
    declare moddir=${moddir}

    inst_hook mount 30 "${moddir}/nfs-mount.sh"

    inst_rules 70-persistent-net.rules
    dracut_need_initqueue
}

