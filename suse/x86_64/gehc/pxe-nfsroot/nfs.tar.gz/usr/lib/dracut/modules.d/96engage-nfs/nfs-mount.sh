#!/bin/bash
type getarg >/dev/null 2>&1 || . /lib/dracut-lib.sh

nfs_root=$(getarg root=)

try_count=10
loop_count=1

while true;do
    /sbin/nfsroot lan0 "${nfs_root}" /sysroot
    if [ -e /sysroot/proc ];then
        break
    fi
    if [ "${loop_count}" -ge "${try_count}" ];then
        break
    fi
    sleep 5
    loop_count=$((loop_count + 1))
done
